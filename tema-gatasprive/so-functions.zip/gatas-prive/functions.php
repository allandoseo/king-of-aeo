<?php
/**
 * Tema "Gatas Prive" — diretorio de uma cidade so.
 *
 * Decisao de estrutura que explica o resto do arquivo: como o site atende um
 * unico municipio, nao existe hierarquia estado > cidade. A taxonomia e BAIRRO,
 * plana. Isso corta URL, menu, consulta e manutencao — e e o que torna o site
 * barato. Se um dia precisar de outra cidade, o certo e outro site, nao
 * remendar hierarquia aqui.
 */

if (!defined('ABSPATH')) exit;

define('GP_VER', '1.0');

/* ---------------------------------------------------------------- suporte */
add_action('after_setup_theme', function () {
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  add_theme_support('automatic-feed-links');
  add_theme_support('html5', ['search-form', 'caption', 'gallery', 'style', 'script']);
  add_theme_support('custom-logo', ['height' => 62, 'width' => 320, 'flex-height' => true, 'flex-width' => true]);
  register_nav_menus(['rodape' => 'Links do rodape']);

  add_image_size('gp-card', 600, 800, true);    // 3:4, o card da grade
  add_image_size('gp-dest', 160, 160, true);    // avatar redondo
  add_image_size('gp-grande', 1200, 900, false);
});

/* ------------------------------------------------------------ css e fonte */
add_action('wp_enqueue_scripts', function () {
  wp_enqueue_style('gp-fontes',
    'https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap', [], null);

  $css = get_stylesheet_directory() . '/style.css';
  wp_enqueue_style('gp', get_stylesheet_uri(), [], file_exists($css) ? filemtime($css) : GP_VER);

  if (is_singular('perfil')) {
    $js = get_theme_file_path('js/galeria.js');
    wp_enqueue_script('gp-galeria', get_theme_file_uri('js/galeria.js'), [],
      file_exists($js) ? filemtime($js) : GP_VER, true);
  }
});

/* ------------------------------------------------ tipo de conteudo e taxonomias */
add_action('init', function () {

  register_post_type('perfil', [
    'label'         => 'Anuncios',
    'labels'        => [
      'name'          => 'Anuncios',
      'singular_name' => 'Anuncio',
      'add_new_item'  => 'Novo anuncio',
      'edit_item'     => 'Editar anuncio',
      'search_items'  => 'Buscar anuncios',
    ],
    'public'        => true,
    'has_archive'   => 'acompanhantes',
    'menu_icon'     => 'dashicons-heart',
    'menu_position' => 5,
    'rewrite'       => ['slug' => 'acompanhante', 'with_front' => false],
    'supports'      => ['title', 'editor', 'thumbnail', 'excerpt'],
    'show_in_rest'  => true,
  ]);

  // bairro: plana de proposito, nao hierarquica
  register_taxonomy('bairro', 'perfil', [
    'label'        => 'Bairros',
    'hierarchical' => false,
    'public'       => true,
    'rewrite'      => ['slug' => 'acompanhantes', 'with_front' => false],
    'show_in_rest' => true,
    'show_admin_column' => true,
  ]);

  register_taxonomy('tipo', 'perfil', [
    'label'        => 'Categorias',
    'hierarchical' => true,
    'public'       => true,
    'rewrite'      => ['slug' => 'categoria', 'with_front' => false],
    'show_in_rest' => true,
    'show_admin_column' => true,
  ]);
});

/* --------------------------------------------------------------- helpers */

/** Campos do anuncio, na ordem em que saem no painel lateral. */
function gp_campos() {
  return [
    'gp_idade'   => 'Idade',
    'gp_altura'  => 'Altura',
    'gp_atende'  => 'Atende',
    'gp_horario' => 'Horario',
    'gp_cache'   => 'Cache',
  ];
}

/** So os numeros do WhatsApp; vazio quando nao houver. */
function gp_whatsapp($post_id = null) {
  $n = preg_replace('/\D/', '', (string) get_post_meta($post_id ? $post_id : get_the_ID(), 'gp_wpp', true));
  if ($n === '') return '';
  if (strlen($n) <= 11) $n = '55' . $n;   // sem DDI, assume Brasil
  return $n;
}

/** Primeiro bairro do anuncio. */
function gp_bairro($post_id = null) {
  $t = get_the_terms($post_id ? $post_id : get_the_ID(), 'bairro');
  return (!$t || is_wp_error($t)) ? null : $t[0];
}

/**
 * Fotos do anuncio: as imagens anexadas a ele. O fluxo e criar o anuncio,
 * subir as fotos nele e publicar — sem bloco de galeria, sem campo extra.
 * A destacada fica de fora porque ja e a capa na grade.
 */
function gp_fotos($post_id = null) {
  $post_id = $post_id ? $post_id : get_the_ID();
  $fotos = get_children([
    'post_parent'    => $post_id,
    'post_type'      => 'attachment',
    'post_mime_type' => 'image',
    'orderby'        => 'menu_order ID',
    'order'          => 'ASC',
    'numberposts'    => -1,
  ]);
  $capa = (int) get_post_thumbnail_id($post_id);
  if ($capa && isset($fotos[$capa])) unset($fotos[$capa]);
  return $fotos;
}

/** Capa: a destacada, ou a primeira foto. Evita card vazio por esquecimento. */
function gp_capa_id($post_id = null) {
  $post_id = $post_id ? $post_id : get_the_ID();
  $capa = (int) get_post_thumbnail_id($post_id);
  if ($capa) return $capa;
  $fotos = gp_fotos($post_id);
  if (!$fotos) return 0;
  $p = reset($fotos);
  return (int) $p->ID;
}

function gp_e_destaque($post_id = null) {
  return get_post_meta($post_id ? $post_id : get_the_ID(), 'gp_destaque', true) === '1';
}

/** Consulta padrao da grade. */
function gp_consulta($args = []) {
  return new WP_Query(array_merge([
    'post_type'      => 'perfil',
    'posts_per_page' => 24,
    'post_status'    => 'publish',
  ], $args));
}

function gp_paginacao($q = null) {
  $args = ['type' => 'array', 'prev_text' => '&lsaquo;', 'next_text' => '&rsaquo;'];
  if ($q) { $args['total'] = $q->max_num_pages; }
  $links = paginate_links($args);
  if (!$links) return;
  echo '<nav class="gp-pag" aria-label="Paginacao">' . implode('', $links) . '</nav>';
}

/* --------------------------------------------------------- campos no admin */
add_action('add_meta_boxes', function () {
  add_meta_box('gp_dados', 'Dados do anuncio', function ($post) {
    wp_nonce_field('gp_salva', 'gp_nonce');
    $v = function ($k) use ($post) { return esc_attr(get_post_meta($post->ID, $k, true)); };

    echo '<p><label><strong>WhatsApp</strong><br>';
    echo '<input name="gp_wpp" value="' . $v('gp_wpp') . '" class="widefat" ';
    echo 'placeholder="62 99999-9999"></label>';
    echo '<span class="description">So numeros ou com formatacao; o tema limpa. '
       . 'Sem DDI, assume 55.</span></p>';

    foreach (gp_campos() as $k => $rotulo) {
      echo '<p><label><strong>' . esc_html($rotulo) . '</strong><br>';
      echo '<input name="' . esc_attr($k) . '" value="' . $v($k) . '" class="widefat"></label></p>';
    }

    echo '<p><label><input type="checkbox" name="gp_destaque" value="1" ';
    echo checked($v('gp_destaque'), '1', false) . '> <strong>Destaque</strong></label><br>';
    echo '<span class="description">Aparece na faixa de cima e ganha selo no card.</span></p>';
  }, 'perfil', 'side', 'high');
});

add_action('save_post_perfil', function ($id) {
  if (!isset($_POST['gp_nonce']) || !wp_verify_nonce($_POST['gp_nonce'], 'gp_salva')) return;
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  if (!current_user_can('edit_post', $id)) return;

  update_post_meta($id, 'gp_wpp', preg_replace('/[^0-9+ ()-]/', '', $_POST['gp_wpp'] ?? ''));
  foreach (array_keys(gp_campos()) as $k) {
    update_post_meta($id, $k, sanitize_text_field($_POST[$k] ?? ''));
  }
  update_post_meta($id, 'gp_destaque', isset($_POST['gp_destaque']) ? '1' : '');
});

/* ------------------------------------------------------------ Customizer */
add_action('customize_register', function ($wp) {

  $wp->add_section('gp_geral', ['title' => 'Site', 'priority' => 25]);
  if ($wp->get_control('custom_logo')) {
    $wp->get_control('custom_logo')->section  = 'gp_geral';
    $wp->get_control('custom_logo')->priority = 5;
  }

  $wp->add_setting('gp_cidade', ['default' => 'Goiania', 'sanitize_callback' => 'sanitize_text_field']);
  $wp->add_control('gp_cidade', [
    'label' => 'Cidade', 'description' => 'Usada nos titulos e nas etiquetas dos cards.',
    'type' => 'text', 'section' => 'gp_geral',
  ]);

  $wp->add_setting('gp_tagline', [
    'default' => 'Acompanhantes em Goiania', 'sanitize_callback' => 'sanitize_text_field',
  ]);
  $wp->add_control('gp_tagline', [
    'label' => 'Linha sob a marca', 'type' => 'text', 'section' => 'gp_geral',
  ]);

  $wp->add_setting('gp_intro', ['default' => '', 'sanitize_callback' => 'wp_kses_post']);
  $wp->add_control('gp_intro', [
    'label' => 'Texto de abertura da home',
    'description' => 'A caixa no alto. Nas paginas de bairro o tema usa a descricao do bairro.',
    'type' => 'textarea', 'section' => 'gp_geral',
  ]);

  $wp->add_setting('gp_wpp_anuncio', ['default' => '', 'sanitize_callback' => 'sanitize_text_field']);
  $wp->add_control('gp_wpp_anuncio', [
    'label' => 'WhatsApp para anunciar',
    'description' => 'Para onde vai o botao "Publicar anuncio". Vazio, o botao aponta '
                   . 'para a pagina /anunciar/.',
    'type' => 'text', 'section' => 'gp_geral',
  ]);

  $wp->add_setting('gp_disclaimer', [
    'default'           => 'Conteudo destinado a maiores de 18 anos. O site divulga anuncios de '
                         . 'terceiros e nao intermedia, agencia ou se responsabiliza por servicos '
                         . 'combinados entre as partes.',
    'sanitize_callback' => 'wp_kses_post',
  ]);
  $wp->add_control('gp_disclaimer', [
    'label' => 'Aviso do rodape', 'type' => 'textarea', 'section' => 'gp_geral',
  ]);

  /* ---- portao 18+ ---- */
  $wp->add_section('gp_idade', [
    'title' => 'Portao 18+', 'priority' => 26,
    'description' => 'Desligado por padrao. Ligado, o aviso aparece so para quem ainda nao '
                   . 'confirmou — o conteudo da pagina continua indo inteiro no HTML, entao o '
                   . 'buscador ve o mesmo que o visitante.',
  ]);
  $wp->add_setting('gp_idade_ativo', ['default' => false, 'sanitize_callback' => 'wp_validate_boolean']);
  $wp->add_control('gp_idade_ativo', [
    'label' => 'Mostrar o portao 18+', 'type' => 'checkbox', 'section' => 'gp_idade',
  ]);
  $wp->add_setting('gp_idade_saida', [
    'default' => 'https://www.google.com.br', 'sanitize_callback' => 'esc_url_raw',
  ]);
  $wp->add_control('gp_idade_saida', [
    'label' => 'Para onde vai quem clica em Sair', 'type' => 'url', 'section' => 'gp_idade',
  ]);

  /* ---- verificacao ---- */
  $wp->add_section('gp_verificacao', ['title' => 'Verificacao do Google', 'priority' => 27]);
  $wp->add_setting('gp_google_verify', ['default' => '', 'sanitize_callback' => 'sanitize_text_field']);
  $wp->add_control('gp_google_verify', [
    'label' => 'google-site-verification',
    'description' => 'So o codigo. O Yoast tem campo igual; use um ou outro, nunca os dois.',
    'type' => 'text', 'section' => 'gp_verificacao',
  ]);
});

add_action('wp_head', function () {
  $c = trim((string) get_theme_mod('gp_google_verify', ''));
  if ($c === '') return;
  printf('<meta name="google-site-verification" content="%s" />' . "\n", esc_attr($c));
}, 1);

/* -------------------------------------------- busca so nos anuncios */
add_action('pre_get_posts', function ($q) {
  if (is_admin() || !$q->is_main_query()) return;

  if ($q->is_search()) $q->set('post_type', 'perfil');

  // destaque primeiro em toda listagem: e o que o anunciante paga para ter
  if ($q->is_post_type_archive('perfil') || $q->is_tax(['bairro', 'tipo'])) {
    $q->set('posts_per_page', 24);
    gp_ordena_destaque($q);
  }
});

/* ---------------------------------------------- home mostra os anuncios */
// Sem pagina estatica e sem posts: a home e o arquivo de anuncios.
add_action('pre_get_posts', function ($q) {
  if (is_admin() || !$q->is_main_query()) return;
  if (!$q->is_home() || $q->is_page()) return;
  $q->set('post_type', 'perfil');
  $q->set('posts_per_page', 24);
  gp_ordena_destaque($q);
});

/**
 * Destaque primeiro, sem perder quem nao tem o campo.
 *
 * Usar so meta_key no WP_Query faz o WordPress montar um INNER JOIN com a
 * tabela de metas, e aí todo anuncio que nunca teve o campo "Destaque" gravado
 * some da listagem. O meta_query com EXISTS / NOT EXISTS em OR mantem todos e
 * ainda permite ordenar pelo valor.
 */
function gp_ordena_destaque($q) {
  $q->set('meta_query', [
    'relation' => 'OR',
    'com'  => ['key' => 'gp_destaque', 'compare' => 'EXISTS'],
    'sem'  => ['key' => 'gp_destaque', 'compare' => 'NOT EXISTS'],
  ]);
  $q->set('orderby', ['com' => 'DESC', 'date' => 'DESC']);
}

/* ------------------------------------------------------- limpeza do head */
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_shortlink_wp_head');
add_filter('the_generator', '__return_empty_string');
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');

/* ----------------------------------- regravar regras ao mexer em taxonomia */
foreach (['created_bairro', 'edited_bairro', 'delete_bairro',
          'created_tipo', 'edited_tipo', 'delete_tipo'] as $gp_gatilho) {
  add_action($gp_gatilho, function () { flush_rewrite_rules(false); });
}
add_action('after_switch_theme', function () { flush_rewrite_rules(false); });
